﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_2._4___more
{
    internal class EmptyTile
    {
        public int X { get; set; }
        public int Y { get; set; }
        public Level.TileType TileType { get; private set; }

        // Constructor
        public EmptyTile(int x, int y)
        {
            X = x;
            Y = y;
            TileType = Level.TileType.Empty;
        }

        // Display property to return '.'
        public char DisplayCharacter
        {
            get { return '.'; }
        }

    }
}
